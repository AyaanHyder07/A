package com.example.demo33;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo33ApplicationTests {

	@Test
	void contextLoads() {
	}

}
